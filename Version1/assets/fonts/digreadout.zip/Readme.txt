------------------------------------------------------------------
DIGITAL READOUT v1.1, created by ShyWedge, 1999.
------------------------------------------------------------------

The following TrueType fonts are included:

 - Digital Readout
 - Digital Readout Condensed
 - Digital Readout CondUpright
 - Digital Readout Expanded
 - Digital Readout ExpUpright
 - Digital Readout Thick
 - Digital Readout Thick Upright
 - Digital Readout Upright

v1.1 UPDATES
------------------------------------------------------------------

 - Punctuation has beed added.
 - Improved lettering and spacing.


This font package is Freeware.  If you wish to distribute it,
please include all of the above fonts along with this document
and send me an e-mail to let me know which font you have so I can
inform you of the latest updates.

Thank you for downloading this font package and enjoy!

ShyFonts by ShyWedge, 1999.
------------------------------------------------------------------
Web Site:  http://welcome.to/ShyFonts
E-mail:    ShyWedge@yahoo.com